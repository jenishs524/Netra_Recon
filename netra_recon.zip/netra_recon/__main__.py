from netra_recon.cli.main import main

if __name__ == "__main__":
    main()