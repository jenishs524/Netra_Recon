#!/usr/bin/env python3
import ipaddress
import json
import os
import platform
import socket
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from itertools import islice

from colorama import Fore, Style, init
from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.table import Table

from netra_recon.config.settings import DEFAULT_TIMEOUT, EXPORT_SETTINGS, RESULTS_DIR
from netra_recon.utils.util import clean_domain_input, ensure_directory_exists, write_to_file

init(autoreset=True)
console = Console()


def banner() -> None:
    console.print(f"{Fore.GREEN}{'=' * 44}")
    console.print(f"{Fore.GREEN}      Netra Recon - IPv6 Enumerator")
    console.print(f"{Fore.GREEN}{'=' * 44}{Style.RESET_ALL}")


def resolve_ipv6_addresses(target: str, max_hosts: int) -> list[str]:
    try:
        network = ipaddress.ip_network(target, strict=False)
    except ValueError:
        network = None

    if network is not None:
        if network.version != 6:
            return []
        return [str(address) for address in islice(network.hosts(), max_hosts)]

    try:
        results = socket.getaddrinfo(
            target, None, family=socket.AF_INET6, type=socket.SOCK_STREAM
        )
    except socket.gaierror:
        return []

    addresses = dict.fromkeys(result[4][0] for result in results)
    return list(islice(addresses, max_hosts))


def ping6(ip: str, timeout: float) -> bool:
    if platform.system() == "Windows":
        cmd = ["ping", "-6", "-n", "1", "-w", str(int(timeout * 1000)), ip]
    else:
        cmd = ["ping", "-6", "-c", "1", "-W", str(int(timeout)), ip]
    try:
        result = subprocess.run(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout + 2,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return False
    return result.returncode == 0


def run(target: str, threads: int, opts: dict | None = None) -> None:
    banner()
    opts = opts or {}
    threads = int(opts.get("threads", threads))
    timeout = float(opts.get("timeout", DEFAULT_TIMEOUT))
    max_hosts = int(opts.get("max_hosts", 256))
    if threads < 1 or timeout <= 0 or max_hosts < 1:
        raise ValueError("threads, timeout, and max_hosts must be positive.")

    target = clean_domain_input(target)
    addresses = resolve_ipv6_addresses(target, max_hosts)
    if not addresses:
        console.print(f"[yellow][*] No IPv6 addresses found for {target}[/yellow]")

    live = set()
    console.print(f"[white][*] Probing {len(addresses)} IPv6 addresses for {target}[/white]")
    with Progress(
        SpinnerColumn(),
        TextColumn("{task.description}"),
        BarColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Probing…", total=len(addresses))
        with ThreadPoolExecutor(max_workers=threads) as pool:
            futures = {pool.submit(ping6, address, timeout): address for address in addresses}
            for future in as_completed(futures):
                address = futures[future]
                if future.result():
                    live.add(address)
                progress.update(task, description=address, advance=1)

    table = Table(
        title=f"IPv6 Reachability – {target}",
        show_header=True,
        header_style="bold magenta",
    )
    table.add_column("IPv6 Address", style="cyan")
    table.add_column("Reachable", style="green")
    table.add_column("PTR", style="yellow", overflow="fold")

    for address in addresses:
        ptr = "-"
        if address in live:
            try:
                ptr = socket.gethostbyaddr(address)[0]
            except OSError:
                pass
        table.add_row(address, "Yes" if address in live else "No", ptr)

    console.print(table)
    console.print(f"[white][*] Reachability test completed: {len(live)} reachable[/white]")

    if EXPORT_SETTINGS.get("enable_txt_export"):
        out_dir = os.path.join(RESULTS_DIR, target)
        ensure_directory_exists(out_dir)
        export_console = Console(record=True, width=console.width)
        export_console.print(table)
        write_to_file(
            os.path.join(out_dir, "ipv6_enumeration.txt"),
            export_console.export_text(),
        )


def main() -> None:
    if len(sys.argv) < 2:
        console.print("[red][!] Usage: ipv6_reachability_test.py <domain|IPv6> [threads] [options_json][/red]")
        sys.exit(1)

    target = sys.argv[1]
    threads = 1
    opts = {}
    if len(sys.argv) > 2:
        if sys.argv[2].isdigit():
            threads = int(sys.argv[2])
        else:
            opts = json.loads(sys.argv[2])
    if len(sys.argv) > 3:
        opts.update(json.loads(sys.argv[3]))
    run(target, threads, opts)


if __name__ == "__main__":
    main()
