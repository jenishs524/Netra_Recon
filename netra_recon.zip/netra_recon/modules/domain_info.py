"""Collect DNS, RDAP, and IP metadata for a domain."""

from __future__ import annotations

import argparse
import ipaddress
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import dns.exception
import dns.resolver
import requests
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.table import Table

from netra_recon.config.settings import (
    DEFAULT_TIMEOUT,
    EXPORT_SETTINGS,
    HEADERS,
    RESULTS_DIR,
)

DNS_RECORD_TYPES = ("A", "AAAA", "MX", "NS", "TXT", "CAA", "SOA")
MAX_TIMEOUT = 120
MAX_THREADS = 8
console = Console()


def normalize_domain(target: str) -> str:
    """Return a validated, IDNA-encoded hostname from a domain or HTTP(S) URL."""
    value = target.strip()
    if not value:
        raise ValueError("A domain or URL is required.")

    if "://" in value:
        parsed = urlparse(value)
        if parsed.scheme.lower() not in {"http", "https"}:
            raise ValueError("Only HTTP and HTTPS URLs are supported.")
    else:
        parsed = urlparse(f"//{value}")

    try:
        hostname = parsed.hostname
        parsed.port
    except ValueError as exc:
        raise ValueError("The target contains an invalid host or port.") from exc

    if not hostname or parsed.username or parsed.password:
        raise ValueError("Enter a valid domain name without embedded credentials.")

    hostname = hostname.rstrip(".").lower()
    if hostname.startswith("www."):
        hostname = hostname[4:]

    try:
        ipaddress.ip_address(hostname)
    except ValueError:
        pass
    else:
        raise ValueError("Enter a domain name, not an IP address.")

    try:
        ascii_hostname = hostname.encode("idna").decode("ascii")
    except UnicodeError as exc:
        raise ValueError("The domain name is not valid IDNA.") from exc

    labels = ascii_hostname.split(".")
    if (
        len(ascii_hostname) > 253
        or len(labels) < 2
        or any(
            not label
            or len(label) > 63
            or re.fullmatch(r"[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", label) is None
            for label in labels
        )
    ):
        raise ValueError("Enter a valid fully qualified domain name.")

    return ascii_hostname


def fetch_dns_records(
    domain: str, timeout: int
) -> tuple[dict[str, list[str]], dict[str, str]]:
    records = {record_type: [] for record_type in DNS_RECORD_TYPES}
    errors: dict[str, str] = {}
    resolver = dns.resolver.Resolver(configure=True)

    for record_type in DNS_RECORD_TYPES:
        try:
            answers = resolver.resolve(domain, record_type, lifetime=timeout)
            records[record_type] = [str(answer).strip('"') for answer in answers]
        except dns.resolver.NXDOMAIN:
            errors["domain"] = "The DNS resolver reports that this domain does not exist."
            break
        except dns.resolver.NoAnswer:
            continue
        except dns.resolver.NoNameservers as exc:
            errors[record_type] = f"No usable nameserver response: {exc}"
        except dns.resolver.LifetimeTimeout:
            errors[record_type] = f"DNS lookup timed out after {timeout} seconds."
        except dns.exception.DNSException as exc:
            errors[record_type] = f"DNS lookup failed: {exc}"

    return records, errors


def fetch_ip_info(ip: str, timeout: int) -> tuple[dict[str, Any] | None, str | None]:
    url = f"https://ip-api.com/json/{ip}?fields=status,message,country,org,as,lat,lon"
    try:
        response = requests.get(url, headers=HEADERS, timeout=timeout)
        response.raise_for_status()
        data = response.json()
    except (requests.RequestException, ValueError) as exc:
        return None, f"IP metadata request failed: {exc}"

    if not isinstance(data, dict):
        return None, "IP metadata service returned an unexpected response."
    if data.get("status") != "success":
        message = data.get("message", "The IP metadata service did not return a result.")
        return None, str(message)

    return (
        {
            "ip": ip,
            "country": data.get("country", "-"),
            "organization": data.get("org", "-"),
            "asn": data.get("as", "-"),
            "latitude": data.get("lat", "-"),
            "longitude": data.get("lon", "-"),
        },
        None,
    )


def fetch_rdap(domain: str, timeout: int) -> tuple[dict[str, Any] | None, str | None]:
    url = f"https://rdap.org/domain/{domain}"
    try:
        response = requests.get(url, headers=HEADERS, timeout=timeout)
        response.raise_for_status()
        data = response.json()
    except (requests.RequestException, ValueError) as exc:
        return None, f"RDAP request failed: {exc}"

    if not isinstance(data, dict):
        return None, "The RDAP service returned an unexpected response."
    return data, None


def _vcard_values(entity: dict[str, Any], property_name: str) -> list[str]:
    vcard_array = entity.get("vcardArray")
    if not isinstance(vcard_array, list) or len(vcard_array) < 2:
        return []

    properties = vcard_array[1]
    if not isinstance(properties, list):
        return []

    values = []
    for item in properties:
        if (
            isinstance(item, list)
            and len(item) >= 4
            and isinstance(item[0], str)
            and item[0].lower() == property_name.lower()
            and item[3] not in (None, "")
        ):
            values.append(str(item[3]))
    return values


def parse_rdap_domain(data: dict[str, Any] | None) -> list[tuple[str, str]]:
    if not data:
        return []

    registrar = "-"
    entities = data.get("entities", [])
    if not isinstance(entities, list):
        entities = []
    for entity in entities:
        if not isinstance(entity, dict):
            continue
        roles = entity.get("roles", [])
        if "registrar" in roles:
            names = _vcard_values(entity, "fn")
            registrar = names[0] if names else entity.get("handle", "-")
            break

    nameserver_data = data.get("nameservers", [])
    if not isinstance(nameserver_data, list):
        nameserver_data = []
    nameservers = [
        server["ldhName"]
        for server in nameserver_data
        if isinstance(server, dict) and server.get("ldhName")
    ]
    statuses = data.get("status", [])
    if not isinstance(statuses, list):
        statuses = []

    secure_dns = data.get("secureDNS", {})
    dnssec = "Signed" if isinstance(secure_dns, dict) and secure_dns.get("delegationSigned") else "Not reported"

    return [
        ("Domain", str(data.get("ldhName", "-"))),
        ("Handle", str(data.get("handle", "-"))),
        ("Registrar", str(registrar)),
        ("Status", ", ".join(map(str, statuses)) or "-"),
        ("Nameservers", ", ".join(map(str, nameservers)) or "-"),
        ("DNSSEC", dnssec),
    ]


def parse_rdap_entities(data: dict[str, Any] | None) -> list[tuple[str, str, str]]:
    if not data:
        return []

    rows = []
    entities = data.get("entities", [])
    if not isinstance(entities, list):
        return rows
    for entity in entities:
        if not isinstance(entity, dict):
            continue
        roles = entity.get("roles", [])
        roles_text = ", ".join(map(str, roles)) if isinstance(roles, list) else "-"
        names = _vcard_values(entity, "fn")
        emails = _vcard_values(entity, "email")
        rows.append((roles_text or "-", names[0] if names else "-", ", ".join(emails) or "-"))
    return rows


def parse_rdap_events(data: dict[str, Any] | None) -> list[tuple[str, str]]:
    if not data:
        return []
    events = data.get("events", [])
    if not isinstance(events, list):
        return []
    return [
        (str(event.get("eventAction", "-")), str(event.get("eventDate", "-")))
        for event in events
        if isinstance(event, dict)
    ]


def _make_dns_table(records: dict[str, list[str]]) -> Table:
    table = Table(title="DNS Records", header_style="bold magenta", box=box.MINIMAL)
    table.add_column("Type", style="cyan", no_wrap=True)
    table.add_column("Values", style="green", overflow="fold")
    for record_type, values in records.items():
        table.add_row(record_type, ", ".join(values) or "-")
    return table


def _make_rdap_table(fields: list[tuple[str, str]]) -> Table:
    table = Table(title="Domain Registration (RDAP)", header_style="bold magenta", box=box.MINIMAL)
    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Value", style="green", overflow="fold")
    for key, value in fields:
        table.add_row(key, value)
    return table


def _make_ip_table(ip_information: list[dict[str, Any]]) -> Table:
    table = Table(title="IP Metadata", header_style="bold magenta", box=box.MINIMAL)
    for column in ("IP", "Country", "Organization", "ASN", "Latitude", "Longitude"):
        table.add_column(column, overflow="fold")
    for item in ip_information:
        table.add_row(
            str(item["ip"]),
            str(item["country"]),
            str(item["organization"]),
            str(item["asn"]),
            str(item["latitude"]),
            str(item["longitude"]),
        )
    return table


def run(target: str, threads: int = 4, opts: dict[str, Any] | None = None) -> dict[str, Any]:
    if opts is None:
        options: dict[str, Any] = {}
    elif isinstance(opts, dict):
        options = opts
    else:
        raise ValueError("Module options must be a JSON object.")
    try:
        timeout = int(options.get("timeout", DEFAULT_TIMEOUT))
    except (TypeError, ValueError) as exc:
        raise ValueError("The timeout option must be an integer.") from exc
    if not 1 <= timeout <= MAX_TIMEOUT:
        raise ValueError(f"Timeout must be between 1 and {MAX_TIMEOUT} seconds.")
    if isinstance(threads, bool) or not isinstance(threads, int) or threads < 1:
        raise ValueError("Thread count must be a positive integer.")

    domain = normalize_domain(target)
    workers = min(threads, MAX_THREADS)
    started = time.monotonic()
    warnings: list[dict[str, str]] = []

    console.print()
    console.print("[bold cyan]Netra Recon | Domain Information[/bold cyan]")
    console.print(f"Target: [cyan]{domain}[/cyan]  Timeout: {timeout}s")

    with Progress(
        SpinnerColumn(),
        TextColumn("DNS lookups: {task.completed}/{task.total}"),
        BarColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("DNS", total=1)
        dns_records, dns_errors = fetch_dns_records(domain, timeout)
        progress.advance(task)
    warnings.extend(
        {"source": "DNS", "item": record_type, "message": message}
        for record_type, message in dns_errors.items()
    )

    ips = sorted(set(dns_records["A"] + dns_records["AAAA"]))
    ip_information: list[dict[str, Any]] = []
    if ips:
        with Progress(
            SpinnerColumn(),
            TextColumn("IP metadata: {task.completed}/{task.total}"),
            BarColumn(),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("IP metadata", total=len(ips))
            with ThreadPoolExecutor(max_workers=min(workers, len(ips))) as pool:
                futures = {pool.submit(fetch_ip_info, ip, timeout): ip for ip in ips}
                for future in as_completed(futures):
                    ip = futures[future]
                    result, error = future.result()
                    if result:
                        ip_information.append(result)
                    if error:
                        warnings.append({"source": "IP metadata", "item": ip, "message": error})
                    progress.advance(task)

    with Progress(
        SpinnerColumn(),
        TextColumn("RDAP lookup: {task.completed}/{task.total}"),
        BarColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("RDAP", total=1)
        rdap_data, rdap_error = fetch_rdap(domain, timeout)
        progress.advance(task)
    if rdap_error:
        warnings.append({"source": "RDAP", "item": domain, "message": rdap_error})

    rdap_fields = parse_rdap_domain(rdap_data)
    entities = parse_rdap_entities(rdap_data)
    events = parse_rdap_events(rdap_data)
    dns_table = _make_dns_table(dns_records)
    rdap_table = _make_rdap_table(rdap_fields) if rdap_fields else None
    ip_table = _make_ip_table(ip_information) if ip_information else None

    console.print(dns_table)
    if rdap_table:
        console.print(rdap_table)
    else:
        console.print("[yellow]RDAP registration details were unavailable.[/yellow]")
    if ip_table:
        console.print(ip_table)

    entity_table = None
    if entities:
        entity_table = Table(title="RDAP Contacts", header_style="bold magenta", box=box.MINIMAL)
        entity_table.add_column("Roles", style="cyan")
        entity_table.add_column("Name", style="green")
        entity_table.add_column("Email", style="yellow", overflow="fold")
        for entity in entities:
            entity_table.add_row(*entity)
        console.print(entity_table)

    event_table = None
    if events:
        event_table = Table(title="Registration Events", header_style="bold magenta", box=box.MINIMAL)
        event_table.add_column("Event", style="cyan")
        event_table.add_column("Date", style="green")
        for event in events:
            event_table.add_row(*event)
        console.print(event_table)

    warning_table = None
    if warnings:
        warning_table = Table(title="Lookup Warnings", header_style="bold yellow", box=box.MINIMAL)
        warning_table.add_column("Source", style="yellow")
        warning_table.add_column("Item", style="cyan")
        warning_table.add_column("Details", overflow="fold")
        for warning in warnings:
            warning_table.add_row(warning["source"], warning["item"], warning["message"])
        console.print(warning_table)

    elapsed = time.monotonic() - started
    queried_at = datetime.now(timezone.utc).isoformat()
    report = {
        "target": domain,
        "queried_at": queried_at,
        "elapsed_seconds": round(elapsed, 2),
        "dns_records": dns_records,
        "rdap": {
            "domain": dict(rdap_fields),
            "entities": [
                {"roles": roles, "name": name, "email": email}
                for roles, name, email in entities
            ],
            "events": [{"action": action, "date": date} for action, date in events],
        },
        "ip_information": ip_information,
        "warnings": warnings,
    }

    summary = (
        f"DNS records: {sum(bool(values) for values in dns_records.values())}/{len(DNS_RECORD_TYPES)} types  "
        f"IP metadata: {len(ip_information)}/{len(ips)}  "
        f"RDAP entities: {len(entities)}  Warnings: {len(warnings)}  "
        f"Elapsed: {elapsed:.2f}s"
    )
    summary_panel = Panel(summary, title="Summary", style="bold white")
    console.print(summary_panel)

    if EXPORT_SETTINGS.get("enable_txt_export") or EXPORT_SETTINGS.get("enable_json_export"):
        output_directory = Path(RESULTS_DIR) / domain
        try:
            output_directory.mkdir(parents=True, exist_ok=True)
            if EXPORT_SETTINGS.get("enable_txt_export"):
                export_console = Console(record=True, width=console.width, no_color=True)
                export_console.print(dns_table)
                if rdap_table:
                    export_console.print(rdap_table)
                if ip_table:
                    export_console.print(ip_table)
                if entity_table:
                    export_console.print(entity_table)
                if event_table:
                    export_console.print(event_table)
                if warnings:
                    export_console.print(warning_table)
                export_console.print(summary_panel)
                (output_directory / "domain_info.txt").write_text(
                    export_console.export_text(), encoding="utf-8"
                )
            if EXPORT_SETTINGS.get("enable_json_export"):
                (output_directory / "domain_info.json").write_text(
                    json.dumps(report, indent=2, ensure_ascii=False) + "\n",
                    encoding="utf-8",
                )
            console.print(f"[green]Results saved to {output_directory}[/green]")
        except OSError as exc:
            console.print(f"[bold red]Unable to save results: {exc}[/bold red]")

    if warnings:
        console.print("[yellow]Lookup completed with warnings; review the warnings table above.[/yellow]")
    else:
        console.print("[green]Domain information lookup completed successfully.[/green]")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description="Collect DNS, RDAP, and IP metadata for a domain.")
    parser.add_argument("target", help="Domain name or HTTP(S) URL")
    parser.add_argument("threads", nargs="?", type=int, default=4, help="Maximum concurrent IP lookups")
    parser.add_argument(
        "options",
        nargs="?",
        default="{}",
        help='Module options as a JSON object, for example \'{"timeout":10}\'',
    )
    args = parser.parse_args()

    try:
        options = json.loads(args.options)
    except json.JSONDecodeError as exc:
        parser.error(f"options must be valid JSON: {exc}")
    try:
        run(args.target, args.threads, options)
    except ValueError as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
